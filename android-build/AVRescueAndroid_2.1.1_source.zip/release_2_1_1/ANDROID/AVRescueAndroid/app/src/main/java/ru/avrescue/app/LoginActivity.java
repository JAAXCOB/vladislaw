package ru.avrescue.app;
import android.app.*;import android.os.*;import android.content.*;import android.text.InputType;import android.widget.*;import org.json.JSONObject;
public class LoginActivity extends Activity {
 EditText login,pass;TextView status;
 public void onCreate(Bundle b){super.onCreate(b);ApiClient.load(this);if(ApiClient.hasToken()){open();return;}
  LinearLayout page=Ui.column(this);page.addView(Ui.brand(this));page.addView(Ui.muted(this,"Найдём помощь рядом",15));
  LinearLayout card=Ui.card(this);card.addView(Ui.text(this,"Вход в AV Rescue",24,true));card.addView(Ui.muted(this,"Один аккаунт для клиента, исполнителя и сотрудников.",14));
  login=Ui.input(this,"Логин или email");pass=Ui.input(this,"Пароль");pass.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);
  Button go=Ui.button(this,"Войти");status=Ui.muted(this,"",14);card.addView(login);card.addView(pass);card.addView(go);
  Button reg=Ui.darkButton(this,"Зарегистрироваться");Button exec=Ui.darkButton(this,"Стать исполнителем");Button b2b=Ui.darkButton(this,"B2B-партнёрам");card.addView(reg);card.addView(exec);card.addView(b2b);card.addView(status);page.addView(card);
  reg.setOnClickListener(v->openRegister("client"));exec.setOnClickListener(v->openRegister("executor"));b2b.setOnClickListener(v->openRegister("b2b"));page.addView(Ui.muted(this,"Защищённое соединение • av-rescue.ru",12));setContentView(page);go.setOnClickListener(v->doLogin());
 }
 void openRegister(String type){Intent i=new Intent(this,RegisterActivity.class);i.putExtra("type",type);startActivity(i);}
 void doLogin(){status.setText("Проверяем аккаунт…");new Thread(()->{try{JSONObject r=ApiClient.post("/api/mobile_login.php",new JSONObject().put("login",login.getText().toString()).put("password",pass.getText().toString()));runOnUiThread(()->{if(r.optBoolean("ok")){ApiClient.saveToken(this,r.optString("token"));open();}else status.setText(r.optString("error","Ошибка входа"));});}catch(Exception e){runOnUiThread(()->status.setText("Нет связи с AV Rescue"));}}).start();}
 void open(){startActivity(new Intent(this,DashboardActivity.class));finish();}
}