package ru.avrescue.app;

import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.location.*;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.*;
import org.json.*;

public class DriverLocationService extends Service implements LocationListener {
 public static final String ACTION_START="ru.avrescue.app.START_DRIVER_SERVICE";
 public static final String ACTION_STOP="ru.avrescue.app.STOP_DRIVER_SERVICE";
 public static final String ACTION_STOP_ALERT="ru.avrescue.app.STOP_ORDER_ALERT";
 private static final String CHANNEL_TRACKING="driver_tracking";
 private static final String CHANNEL_ORDERS="new_orders_v2";
 private final Handler handler=new Handler(Looper.getMainLooper());
 private LocationManager locationManager;private volatile Location lastLocation;private volatile long lastHeartbeatElapsed=0;private String alertedOfferId="";private Ringtone ringtone;
 private final Runnable poll=new Runnable(){public void run(){pollOrders();handler.postDelayed(this,8000);}};

 public void onCreate(){super.onCreate();ApiClient.load(this);createChannels();startForeground(4101,trackingNotification());startLocation();handler.post(poll);}
 public int onStartCommand(Intent intent,int flags,int startId){String action=intent==null?ACTION_START:intent.getAction();if(ACTION_STOP_ALERT.equals(action)){stopAlert();return START_STICKY;}if(ACTION_STOP.equals(action)){stopAlert();stopSelf();return START_NOT_STICKY;}return START_STICKY;}
 public android.os.IBinder onBind(Intent intent){return null;}

 private void createChannels(){NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);if(Build.VERSION.SDK_INT>=26){NotificationChannel tracking=new NotificationChannel(CHANNEL_TRACKING,"Работа на линии",NotificationManager.IMPORTANCE_LOW);tracking.setSound(null,null);nm.createNotificationChannel(tracking);NotificationChannel orders=new NotificationChannel(CHANNEL_ORDERS,"Новые заказы",NotificationManager.IMPORTANCE_HIGH);orders.enableVibration(true);nm.createNotificationChannel(orders);}}
 private Notification trackingNotification(){Intent open=new Intent(this,DashboardActivity.class).putExtra("open_line",true);PendingIntent pi=PendingIntent.getActivity(this,4101,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(this,CHANNEL_TRACKING):new Notification.Builder(this);return b.setSmallIcon(android.R.drawable.ic_menu_mylocation).setContentTitle("AV Rescue — вы на линии").setContentText("Геопозиция и новые заказы обновляются в фоне").setOngoing(true).setContentIntent(pi).build();}
 private void startLocation(){locationManager=(LocationManager)getSystemService(LOCATION_SERVICE);if(Build.VERSION.SDK_INT>=23&&checkSelfPermission(android.Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED){stopSelf();return;}try{if(locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER))locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER,10000,10,this);if(locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER))locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER,10000,10,this);Location x=locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);if(x==null)x=locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);if(x!=null)sendLocation(x);}catch(Exception ignored){}}
 public void onLocationChanged(Location location){sendLocation(location);}
 private void sendLocation(Location location){lastLocation=location;lastHeartbeatElapsed=SystemClock.elapsedRealtime();getSharedPreferences("avr",MODE_PRIVATE).edit().putLong("last_lat",Double.doubleToRawLongBits(location.getLatitude())).putLong("last_lng",Double.doubleToRawLongBits(location.getLongitude())).apply();new Thread(()->{try{ApiClient.post("/api/mobile_location.php",new JSONObject().put("lat",location.getLatitude()).put("lng",location.getLongitude()).put("online",true));}catch(Exception ignored){}}).start();}
 private void heartbeat() throws Exception{long now=SystemClock.elapsedRealtime();if(now-lastHeartbeatElapsed<30000)return;lastHeartbeatElapsed=now;double lat=0,lng=0;Location current=lastLocation;if(current!=null){lat=current.getLatitude();lng=current.getLongitude();}else{android.content.SharedPreferences p=getSharedPreferences("avr",MODE_PRIVATE);long a=p.getLong("last_lat",0),b=p.getLong("last_lng",0);if(a!=0&&b!=0){lat=Double.longBitsToDouble(a);lng=Double.longBitsToDouble(b);}}if(lat!=0&&lng!=0)ApiClient.post("/api/mobile_location.php",new JSONObject().put("lat",lat).put("lng",lng).put("online",true));}
 private void pollOrders(){new Thread(()->{try{heartbeat();JSONObject r=ApiClient.get("/api/mobile_dashboard.php");JSONArray orders=r.optJSONArray("orders");JSONObject offer=null;if(orders!=null)for(int i=0;i<orders.length();i++){JSONObject o=orders.optJSONObject(i);if(o!=null&&"offered".equals(o.optString("status"))){offer=o;break;}}final JSONObject current=offer;handler.post(()->{if(current==null){stopAlert();alertedOfferId="";}else if(!current.optString("id").equals(alertedOfferId)){alertedOfferId=current.optString("id");showOffer(current);}});}catch(Exception ignored){}}).start();}
 private void showOffer(JSONObject order){stopAlert();try{Uri sound=RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);if(sound==null)sound=RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);ringtone=RingtoneManager.getRingtone(this,sound);if(Build.VERSION.SDK_INT>=28)ringtone.setLooping(true);ringtone.play();}catch(Exception ignored){}Intent open=new Intent(this,DashboardActivity.class).putExtra("open_line",true).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP);PendingIntent pi=PendingIntent.getActivity(this,order.optString("id").hashCode(),open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(this,CHANNEL_ORDERS):new Notification.Builder(this);b.setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle("Новый заказ AV Rescue").setContentText(order.optString("service")+" · "+order.optString("address")).setAutoCancel(true).setContentIntent(pi).setPriority(Notification.PRIORITY_MAX);((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).notify(order.optString("id").hashCode(),b.build());}
 private void stopAlert(){try{if(ringtone!=null&&ringtone.isPlaying())ringtone.stop();}catch(Exception ignored){}ringtone=null;if(!alertedOfferId.isEmpty())try{((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).cancel(alertedOfferId.hashCode());}catch(Exception ignored){}}
 public void onProviderEnabled(String provider){}public void onProviderDisabled(String provider){}public void onStatusChanged(String provider,int status,Bundle extras){}
 public void onDestroy(){handler.removeCallbacks(poll);stopAlert();try{if(locationManager!=null)locationManager.removeUpdates(this);}catch(Exception ignored){}super.onDestroy();}
}
